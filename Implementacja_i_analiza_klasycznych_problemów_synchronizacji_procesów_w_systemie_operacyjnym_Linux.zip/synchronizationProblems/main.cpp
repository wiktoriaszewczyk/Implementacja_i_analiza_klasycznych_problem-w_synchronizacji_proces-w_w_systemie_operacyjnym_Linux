#include <SFML/Graphics.hpp>
#include <iostream>

#include "include/Constants.hpp"
#include "include/StartupScreen.hpp"
#include "include/producersConsumersProblem/ProdConsProblemStartup.hpp"
#include "include/producersConsumersProblem/ProducersConsumersProblem.hpp"
#include "include/readersWritersProblem/ReadWriteProblemStartup.hpp"
#include "include/readersWritersProblem/ReadersWritersProblem.hpp"
#include "include/sleepingBarberProblem/SleepBarbProblemStartup.hpp"
#include "include/sleepingBarberProblem/SleepingBarberProblem.hpp"

int main()
{
    // std::cout << "SFML Version: " << SFML_VERSION_MAJOR << "." << SFML_VERSION_MINOR << "." << SFML_VERSION_PATCH << std::endl;

    sf::RenderWindow window(sf::VideoMode(Constants::WINDOW_WIDTH, Constants::WINDOW_HEIGHT), "Klasyczne problemy synchronizacji");
    auto desktop = sf::VideoMode::getDesktopMode();
    window.setPosition(sf::Vector2i(desktop.width/2 - window.getSize().x/2, desktop.height/2 - window.getSize().y/2));

    ProgramStatus programStatus = S_Startup;
    StartupScreen startupScreen(window);

    ProdConsProblemStartup prodConsProblemStartup(window);
    ProducersConsumersProblem producersConsumersProblem(window);

    ReadWriteProblemStartup readWriteProblemStartup(window);
    ReadersWritersProblem readersWritersProblem(window);

    SleepBarbProblemStartup sleepBarbProblemStartup(window);
    SleepingBarberProblem sleepingBarberProblem(window);

    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
            {
                window.close();
            }

            switch(programStatus)
            {
            case S_Startup:
            {
                programStatus = startupScreen.handleEvent(event);
                break;
            }
            case S_ProducersConsumersProblemStartup:
            {
                programStatus = prodConsProblemStartup.handleEvent(event);
                if(programStatus == S_ProducersConsumersProblem)
                {
                    producersConsumersProblem.setup(prodConsProblemStartup.numberOfProducers, prodConsProblemStartup.numberOfConsumers, prodConsProblemStartup.bufferSize, prodConsProblemStartup.productionDuration, prodConsProblemStartup.consumptionDuration);
                }
                break;
            }
            case S_ProducersConsumersProblem:
            {
                break;
            }
            case S_ReadersWritersProblemStartup:
            {
                programStatus = readWriteProblemStartup.handleEvent(event);
                if(programStatus == S_ReadersWritersProblem)
                {
                    readersWritersProblem.setup(readWriteProblemStartup.numberOfReaders, readWriteProblemStartup.numberOfWriters, readWriteProblemStartup.readingDuration, readWriteProblemStartup.writingDuration, readWriteProblemStartup.version);
                }
                break;
            }
            case S_ReadersWritersProblem:
            {
                readersWritersProblem.handleEvent(event);
                break;
            }
            case S_SleepingBarberProblemStartup:
            {
                programStatus = sleepBarbProblemStartup.handleEvent(event);
                if(programStatus == S_SleepingBarberProblem)
                {
                    sleepingBarberProblem.setup(sleepBarbProblemStartup.numberOfCustomers, sleepBarbProblemStartup.numberOfSeats, sleepBarbProblemStartup.haircutDuration);
                }
                break;
            }
            case S_SleepingBarberProblem:
            {
                sleepingBarberProblem.handleEvent(event);
                break;
            }
        }
        }
        window.clear();

        switch(programStatus){
            case S_Startup:
            {
                startupScreen.draw();
                break;
            }
            case S_ProducersConsumersProblemStartup:
            {
                prodConsProblemStartup.draw();
                break;
            }
            case S_ProducersConsumersProblem:
            {
                producersConsumersProblem.draw();
                break;
            }
            case S_ReadersWritersProblemStartup:
            {
                readWriteProblemStartup.draw();
                break;
            }
            case S_ReadersWritersProblem:
            {
                readersWritersProblem.draw();
                break;
            }
            case S_SleepingBarberProblemStartup:
            {
                sleepBarbProblemStartup.draw();
                break;
            }
            case S_SleepingBarberProblem:
            {
                sleepingBarberProblem.draw();
                break;
            }
        }   

        window.display();
    }

    if(programStatus == S_ProducersConsumersProblem)
    {
        producersConsumersProblem.join();
        producersConsumersProblem.del();
    }

    if(programStatus == S_ReadersWritersProblem)
    {
        readersWritersProblem.join();
        readersWritersProblem.del();
    }
    if(programStatus == S_SleepingBarberProblem)
    {
        sleepingBarberProblem.join();
        sleepingBarberProblem.del();
    }

    // std::cout << "SFML Version: " << SFML_VERSION_MAJOR << "." << SFML_VERSION_MINOR << "." << SFML_VERSION_PATCH << std::endl;
    return 0;
}