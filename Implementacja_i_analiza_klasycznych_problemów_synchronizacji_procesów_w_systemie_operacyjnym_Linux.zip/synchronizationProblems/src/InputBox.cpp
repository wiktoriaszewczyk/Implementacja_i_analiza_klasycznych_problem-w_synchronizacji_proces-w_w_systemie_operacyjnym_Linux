#include "../include/InputBox.hpp"
#include <iostream>

void InputBox::setup(std::wstring text, int positionX, int positionY, int value)
{
    inputText = std::to_string(value);

    if (!font.loadFromFile("../fonts/Arial.ttf"))
    {
        std::cout << "Failed to load font" << std::endl;
    }

    title.setFont(font);
    title.setString(text);
    title.setCharacterSize(18);
    title.setFillColor(sf::Color::Black);
    title.setPosition(positionX, positionY);

    rectangle = sf::RectangleShape(sf::Vector2f(100, 20));
    rectangle.setPosition(positionX + 215, positionY);
    rectangle.setFillColor(sf::Color(230, 230, 230));

    input.setFont(font);
    input.setString(inputText);
    input.setCharacterSize(18);
    input.setFillColor(sf::Color::Black);
    input.setPosition(positionX + 220, positionY);
}

void InputBox::draw(sf::RenderWindow& window)
{
    window.draw(title);
    window.draw(rectangle);
    window.draw(input);
}

void InputBox::handleMouseClick(sf::Vector2f mousePosition)
{
    if (rectangle.getGlobalBounds().contains(mousePosition))
    {
        selected = true;
        rectangle.setFillColor(sf::Color::White);
    }
    else
    {
        selected = false;
        rectangle.setFillColor(sf::Color(230, 230, 230));
    }
}

void InputBox::handleTextEntered(sf::Uint32 unicode)
{
    if (selected && (unicode >= 48 && unicode <= 57)) // Check if the entered character is a digit
    {
        inputText += static_cast<char>(unicode);
        input.setString(inputText);
    }
}

void InputBox::handleBackspace()
{
    if (selected && !inputText.empty()) {
        inputText.pop_back();
        input.setString(inputText);
    }
}

std::string InputBox::getValue() const
{
    return inputText;
}