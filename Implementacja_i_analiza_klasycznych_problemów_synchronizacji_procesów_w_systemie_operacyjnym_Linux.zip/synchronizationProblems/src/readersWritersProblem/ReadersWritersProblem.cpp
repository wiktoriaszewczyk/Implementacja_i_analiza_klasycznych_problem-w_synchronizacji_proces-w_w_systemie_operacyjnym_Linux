#include "../../include/readersWritersProblem/ReadersWritersProblem.hpp"

#include <random>
#include <chrono>

ReadersWritersProblem::ReadersWritersProblem(sf::RenderWindow& win)
: window(win)
{}

void ReadersWritersProblem::setup(int nRead, int nWrite, int rDuration, int wDuration, int v)
{
    numberOfReaders = nRead;
    numberOfWriters = nWrite;
    readingDuration = rDuration; 
    writingDuration = wDuration;
    version = v;
    
    // version == 3 (by default): without starvation - fair implementation
        reading = [this](Reader* reader) { reading_withoutStarvation(reader); };
        writing = [this](Writer* writer) { writing_withoutStarvation(writer); };
    if(version == 1) // readers preference
    {
        reading = [this](Reader* reader) { reading_readersPreference(reader); };
        writing = [this](Writer* writer) { writing_readersPreference(writer); };
    } 
    else if(version == 2) // writers preference
    {
        reading = [this](Reader* reader) { reading_writersPreference(reader); };
        writing = [this](Writer* writer) { writing_writersPreference(writer); };
    }

    background.setup(numberOfReaders, numberOfWriters, readingDuration, writingDuration, version);

    int idReader = 1;
    int idWriter = 1;
    positionX = 40;
    positionY = 180;

    resource = 10;
    readersCount = 0;
    writersCount = 0;
    sem_init(&queue, 0, 1);
    sem_init(&accessToResource, 0, 1);
    sem_init(&writerPreference, 0, 1);

    for(int i=0; i<(numberOfReaders + numberOfWriters); i++)
    {
        bool randomOrder = randomBool();
        if(randomOrder && (idReader <= numberOfReaders))
        {
            Reader* reader = new Reader(idReader, window, positionX, positionY);
            readers.push_back(reader);
            readerThreads.push_back(std::thread(reading, reader));
            idReader++;
            updateXYposition();
        }
        else if((!randomOrder) && (idWriter <= numberOfWriters))
        {
            Writer* writer = new Writer(idWriter, window, positionX, positionY);
            writers.push_back(writer);
            writerThreads.push_back(std::thread(writing, writer));
            idWriter++;
            updateXYposition();
        }
        else
        {
            i--;
        }
    }
}

void ReadersWritersProblem::del()
{
    sem_destroy(&queue);
    sem_destroy(&accessToResource);
    sem_destroy(&writerPreference);

    for(auto& reader : readers)
    {
        delete reader;
    }
    for(auto& writer : writers)
    {
        delete writer;
    }
}

void ReadersWritersProblem::draw()
{
    background.draw(window);
    for(auto& reader : readers)
    {
        reader->draw();   
    }
    for(auto& writer : writers)
    {
        writer->draw();   
    }
}

void ReadersWritersProblem::join()
{
    for(auto& rT : readerThreads)
    {
        rT.join();   
    }
    for(auto& wT : writerThreads)
    {
        wT.join();
    }
}

void ReadersWritersProblem::handleEvent(sf::Event event)
{
    if (event.type == sf::Event::KeyPressed)
    {
        if((numberOfReaders + numberOfWriters) < 39)
        {
            if (event.key.code == sf::Keyboard::R)
            {
                Reader* reader = new Reader(numberOfReaders, window, positionX, positionY);
                readers.push_back(reader);
                readerThreads.push_back(std::thread(reading, reader));
                numberOfReaders++;
                updateXYposition();
                background.update(numberOfReaders,numberOfWriters);
            }
            else if (event.key.code == sf::Keyboard::W)
            {
                Writer* writer = new Writer(numberOfWriters, window, positionX, positionY);
                writers.push_back(writer);
                writerThreads.push_back(std::thread(writing, writer));
                numberOfWriters++;
                updateXYposition();
                background.update(numberOfReaders,numberOfWriters);
            }
        }
    }
}

bool ReadersWritersProblem::randomBool()
{
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(0, 1);
    return dis(gen) == 1;
}

void ReadersWritersProblem::updateXYposition()
{
    positionY += 30;
    if(positionY == 570) // next column
    {
        positionY = 180;
        if(positionX == 40) // second column
        {
            positionX = 280;        
        }
        else if(positionX == 280) // third column
        {
            positionX = 530;
        }
    }
}


void ReadersWritersProblem::reading_readersPreference(Reader* reader)
{
    // QUEUE
    reader->update(Reader::WAITING);
    {
        std::lock_guard<std::mutex> lock(accessToReadersCount);
        readersCount++;
        if(readersCount == 1)
        {
            sem_wait(&accessToResource);
        }
    }

    // READING
    int readData = resource;
    reader->update(Reader::READING, readData);
    std::this_thread::sleep_for(std::chrono::seconds(readingDuration));

    // LEAVING
    {
        std::lock_guard<std::mutex> lock(accessToReadersCount);
        readersCount--;
        if(readersCount == 0)
        {
            sem_post(&accessToResource);
        }
    }
    reader->update(Reader::DONE, readData);
    pthread_exit(NULL);
}

void ReadersWritersProblem::writing_readersPreference(Writer* writer)
{
    // QUEUE
    writer->update(Writer::WAITING);
    sem_wait(&accessToResource);

    // WRITING
    resource++;
    int writeData = resource;
    writer->update(Writer::WRITING, writeData);
    std::this_thread::sleep_for(std::chrono::seconds(writingDuration));

    // LEAVING
    sem_post(&accessToResource);
    writer->update(Writer::DONE, writeData);
    pthread_exit(NULL);
}


void ReadersWritersProblem::reading_writersPreference(Reader* reader){
    // QUEUE
    reader->update(Reader::WAITING);
    sem_wait(&writerPreference);
    {
        std::lock_guard<std::mutex> lock(accessToReadersCount);
        readersCount++;
        if(readersCount == 1)
        {
            sem_wait(&accessToResource);
        }
    }
    sem_post(&writerPreference);

    // READING
    int readData = resource;
    reader->update(Reader::READING, readData);
    std::this_thread::sleep_for(std::chrono::seconds(readingDuration));

    // LEAVING
    {
        std::lock_guard<std::mutex> lock(accessToReadersCount);
        readersCount--;
        if(readersCount == 0)
        {
            sem_post(&accessToResource);
        }
    }
    reader->update(Reader::DONE, readData);
    pthread_exit(NULL);
}

void ReadersWritersProblem::writing_writersPreference(Writer* writer){
    // QUEUE
    writer->update(Writer::WAITING);
    {
        std::lock_guard<std::mutex> lock(accessToWritersCount);
        writersCount++;
        if(writersCount == 1)
        {
            sem_wait(&writerPreference);
        }
    }
    sem_wait(&accessToResource);

    // WRITING
    resource++;
    int writeData = resource;
    writer->update(Writer::WRITING, writeData);
    std::this_thread::sleep_for(std::chrono::seconds(writingDuration));

    // LEAVING
    sem_post(&accessToResource);
    {
        std::lock_guard<std::mutex> lock(accessToWritersCount);
        writersCount--;
        if(writersCount == 0)
        {
            sem_post(&writerPreference);
        }
    }
    writer->update(Writer::DONE, writeData);
    pthread_exit(NULL);
}


void ReadersWritersProblem::reading_withoutStarvation(Reader* reader)
{
    // QUEUE
    reader->update(Reader::WAITING);
    sem_wait(&queue);
    {
        std::lock_guard<std::mutex> lock(accessToReadersCount);
        readersCount++;
        if(readersCount == 1)
        {
            sem_wait(&accessToResource);
        }
    }
    sem_post(&queue);

    // READING
    int readData = resource;
    reader->update(Reader::READING, readData);
    std::this_thread::sleep_for(std::chrono::seconds(readingDuration));

    // LEAVING
    {
        std::lock_guard<std::mutex> lock(accessToReadersCount);
        readersCount--;
        if(readersCount == 0)
        {
            sem_post(&accessToResource);
        }
    }
    reader->update(Reader::DONE, readData);
    pthread_exit(NULL);
}

void ReadersWritersProblem::writing_withoutStarvation(Writer* writer)
{
    // QUEUE
    writer->update(Writer::WAITING);
    sem_wait(&queue);
    sem_wait(&accessToResource);
    sem_post(&queue);

    // WRITING
    resource++;
    int writeData = resource;
    writer->update(Writer::WRITING, writeData);
    std::this_thread::sleep_for(std::chrono::seconds(writingDuration));

    // LEAVING
    sem_post(&accessToResource);
    writer->update(Writer::DONE, writeData);
    pthread_exit(NULL);
}
