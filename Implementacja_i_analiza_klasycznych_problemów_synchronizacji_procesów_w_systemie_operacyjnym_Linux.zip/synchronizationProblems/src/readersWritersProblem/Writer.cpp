#include "../../include/readersWritersProblem/Writer.hpp"

#include <iostream>

Writer::Writer(int i, sf::RenderWindow& win, int posX, int posY)
:id(i), window(win), positionX(posX), positionY(posY)
{
    if (!font.loadFromFile("../fonts/Arial.ttf"))
    {
        std::cout << "Failed to load font" << std::endl;
    }

    circle.setFillColor(sf::Color::Red);
    circle.setRadius(6.f);
    circle.setPosition(posX, posY + 4);

    info.setFont(font);
    info.setString(L"Pisarz id: " + std::to_wstring(id) + L", nieaktywny");
    info.setCharacterSize(15);
    info.setFillColor(sf::Color(40, 40, 140));
    info.setPosition(posX + 20, posY);
}

void Writer::update(Status status, int data)
{
    std::wstring text = L"Pisarz id: " + std::to_wstring(id) + L", ";
    if(status == Status::WAITING)
    {
        circle.setFillColor(sf::Color(255, 71, 71));
        text += L"czeka";
    }
    else if(status == Status::WRITING)
    {
        circle.setFillColor(sf::Color(33, 150, 243));
        text += L"pisze: " + std::to_wstring(data);
    }
    else if(status == Status::DONE)
    {
        circle.setFillColor(sf::Color(76, 175, 80));
        text += L"napisał: " + std::to_wstring(data);
    }
    info.setString(text); 
}

void Writer::draw()
{
    window.draw(circle);
    window.draw(info);
}