#include "../../include/readersWritersProblem/ReadWriteProblemStartup.hpp"
#include <iostream>

ReadWriteProblemStartup::ReadWriteProblemStartup(sf::RenderWindow& win)
: window(win)
{
    if (!font.loadFromFile("../fonts/Arial.ttf"))
    {
        std::cout << "Failed to load font" << std::endl;
    }

    bgRec = sf::RectangleShape(sf::Vector2f(Constants::WINDOW_WIDTH, Constants::WINDOW_HEIGHT));
    bgRec.setPosition(0,0);
    bgRec.setFillColor(Constants::BACKGROUND_COLOR);

    title.setFont(font);
    title.setString(L"Problem czytelników i pisarzy");
    title.setCharacterSize(40);
    title.setFillColor(sf::Color::Black);
    title.setPosition(50, 40);

    prompt.setFont(font);
    prompt.setString(L"Określ warunki początkowe: ");
    prompt.setCharacterSize(18);
    prompt.setFillColor(sf::Color::Black);
    prompt.setPosition(50, 120);

    numberOfReadersInput.setup(std::wstring(L"Liczba czytelników: "), 50, 170, numberOfReaders);
    numberOfWritersInput.setup(std::wstring(L"Liczba pisarzy: "), 50, 220, numberOfWriters);
    readingDurationInput.setup(std::wstring(L"Czas trwania czytania: "), 50, 270, readingDuration);
    writingDurationInput.setup(std::wstring(L"Czas trwania pisania: "), 50, 320, writingDuration);
    
    version1Rec = sf::RectangleShape(sf::Vector2f(300, 40));
    version1Rec.setPosition(50, 370);
    version1Rec.setFillColor(sf::Color(100,100,100));

    version1.setFont(font);
    version1.setString(L"Preferencja czytelników");
    version1.setCharacterSize(18);
    version1.setFillColor(sf::Color::Black);
    version1.setPosition(60, 380);

    version2Rec = sf::RectangleShape(sf::Vector2f(300, 40));
    version2Rec.setPosition(50, 420);
    version2Rec.setFillColor(sf::Color(100,100,100));

    version2.setFont(font);
    version2.setString(L"Preferencja pisarzy");
    version2.setCharacterSize(18);
    version2.setFillColor(sf::Color::Black);
    version2.setPosition(60, 430);

    version3Rec = sf::RectangleShape(sf::Vector2f(300, 40));
    version3Rec.setPosition(50, 470);
    version3Rec.setFillColor(sf::Color(100,100,200));

    version3.setFont(font);
    version3.setString(L"Wersja sprawiedliwa");
    version3.setCharacterSize(18);
    version3.setFillColor(sf::Color::Black);
    version3.setPosition(60, 480);

    std::wstring infoText = L"W   problemie   występują   dwa   rodzaje   procesów:\n";
                infoText += L"czytelnik  oraz pisarz.  Obaj  próbują  uzyskać dostęp\n";
                infoText += L"do czytelni.  Czytelnicy  mogą czytać razem z  innymi\n";
                infoText += L"czytelnikami, ale pisarze modyfikując dane w czytelni\n";
                infoText += L"(tu liczbę) muszą być sami. \n";
                infoText += L"\n";
                infoText += L"W symulacji można ustawić warunki początkowe: \n";
                infoText += L"- liczbę czytelników i pisarzy (razem max 39)\n";
                infoText += L"- czas trwania czytania (w sekundach)\n";
                infoText += L"- czas trwania pisania (w sekundach)\n";
                infoText += L"- wersje (klikając w odpowiednie pole z nazwą)\n";
                infoText += L"\n";
                infoText += L"Preferencja  czytelników  -  jeśli  do czytelni  wchodzi\n";
                infoText += L"czytelnik,   wchodzą  z   nim  inni  czytelnicy,  omijając\n";
                infoText += L"pisarzy w kolejce.  Możliwe zagłodzenia pisarzy.\n";
                infoText += L"\n";
                infoText += L"Preferencja pisarzy - jeśli w kolejce jest pisarz, ma on\n";
                infoText += L"pierwszeństwo. Możliwe zagłodzenia czytelników.\n";
                infoText += L"\n";
                infoText += L"Wersja sprawiedliwa  -  czytelnicy (grupowo) i pisarze\n";
                infoText += L"(pojedynczo)   wchodzą    zgodnie   z   kolejką.    Brak\n";
                infoText += L"możliwości zagłodzenia.\n";
                infoText += L"\n";



    info.setFont(font);
    info.setString(infoText);
    info.setCharacterSize(16);
    info.setFillColor(sf::Color::Black);
    info.setPosition(400, 120);

    startRec = sf::RectangleShape(sf::Vector2f(200, 40));
    startRec.setPosition(300, 530);
    startRec.setFillColor(sf::Color(100,100,100));

    start.setFont(font);
    start.setString(L"START");
    start.setCharacterSize(20);
    start.setFillColor(sf::Color::Black);
    start.setPosition(370, 538);
}

void ReadWriteProblemStartup::draw()
{
    window.draw(bgRec);
    window.draw(title);
    window.draw(prompt);
    numberOfReadersInput.draw(window);
    numberOfWritersInput.draw(window);
    readingDurationInput.draw(window);
    writingDurationInput.draw(window);
    window.draw(version1Rec);
    window.draw(version1);
    window.draw(version2Rec);
    window.draw(version2);
    window.draw(version3Rec);
    window.draw(version3);
    window.draw(info);
    window.draw(startRec);
    window.draw(start);
}

ProgramStatus ReadWriteProblemStartup::handleEvent(sf::Event event)
{
    if (event.type == sf::Event::MouseButtonPressed)
    {
        if (event.mouseButton.button == sf::Mouse::Left)
        {
            sf::Vector2f mousePosition(static_cast<float>(event.mouseButton.x), static_cast<float>(event.mouseButton.y));
            return handleMouseClick(mousePosition);
        }
    }
    else if (event.type == sf::Event::MouseMoved) {
        sf::Vector2f mousePosition(static_cast<float>(event.mouseMove.x), static_cast<float>(event.mouseMove.y));
        handleMouseHover(mousePosition);
    }
    else if (event.type == sf::Event::TextEntered) {
        handleTextEntered(event.text.unicode);
    }
    else if (event.type == sf::Event::KeyPressed) {
        if (event.key.code == sf::Keyboard::BackSpace) {
            handleBackspace();
        }
    }
    return S_ReadersWritersProblemStartup;
}

ProgramStatus ReadWriteProblemStartup::handleMouseClick(sf::Vector2f mousePosition){
    numberOfReadersInput.handleMouseClick(mousePosition);
    numberOfWritersInput.handleMouseClick(mousePosition);
    readingDurationInput.handleMouseClick(mousePosition);
    writingDurationInput.handleMouseClick(mousePosition);

    if(version1Rec.getGlobalBounds().contains(mousePosition))
    {
        version = 1;
        version1Rec.setFillColor(sf::Color(100,100,200));
        version2Rec.setFillColor(sf::Color(100,100,100));
        version3Rec.setFillColor(sf::Color(100,100,100));
    }
    else if(version2Rec.getGlobalBounds().contains(mousePosition))
    {
        version = 2;
        version1Rec.setFillColor(sf::Color(100,100,100));
        version2Rec.setFillColor(sf::Color(100,100,200));
        version3Rec.setFillColor(sf::Color(100,100,100));
    }
    else if(version3Rec.getGlobalBounds().contains(mousePosition))
    {
        version = 3;
        version1Rec.setFillColor(sf::Color(100,100,100));
        version2Rec.setFillColor(sf::Color(100,100,100));
        version3Rec.setFillColor(sf::Color(100,100,200));
    }
    else if(startRec.getGlobalBounds().contains(mousePosition)){
        numberOfReaders = std::stoi(numberOfReadersInput.getValue());
        numberOfWriters = std::stoi(numberOfWritersInput.getValue());
        readingDuration = std::stoi(readingDurationInput.getValue());
        writingDuration = std::stoi(writingDurationInput.getValue());

        if(numberOfReaders + numberOfWriters > 39)
        {
            numberOfReaders = 20;
            numberOfWriters = 19;
        }
        numberOfReaders = (numberOfReaders < 0) ? 0 : numberOfReaders;
        numberOfWriters = (numberOfWriters < 0) ? 0 : numberOfWriters;
        readingDuration = (readingDuration < 0) ? 1 : readingDuration;
        writingDuration = (writingDuration < 0) ? 1 : writingDuration;

        version = (version > 0 && version < 4) ? version : 3;
        
        return S_ReadersWritersProblem;
    }
    return S_ReadersWritersProblemStartup;
}

void ReadWriteProblemStartup::handleMouseHover(sf::Vector2f mousePosition)
{
    if(startRec.getGlobalBounds().contains(mousePosition))
        startRec.setFillColor(sf::Color(100,100,200));
    else if(version1Rec.getGlobalBounds().contains(mousePosition))
        version1Rec.setFillColor(sf::Color(100,100,200));
    else if(version2Rec.getGlobalBounds().contains(mousePosition))
        version2Rec.setFillColor(sf::Color(100,100,200));
    else if(version3Rec.getGlobalBounds().contains(mousePosition))
        version3Rec.setFillColor(sf::Color(100,100,200));
    else
    {
        startRec.setFillColor(sf::Color(100,100,100));
        if(version != 1)
            version1Rec.setFillColor(sf::Color(100,100,100));
        if(version != 2)
            version2Rec.setFillColor(sf::Color(100,100,100));
        if(version != 3)
            version3Rec.setFillColor(sf::Color(100,100,100));
    }
}
void ReadWriteProblemStartup::handleTextEntered(sf::Uint32 unicode)
{
    numberOfReadersInput.handleTextEntered(unicode);
    numberOfWritersInput.handleTextEntered(unicode);
    readingDurationInput.handleTextEntered(unicode);
    writingDurationInput.handleTextEntered(unicode);
}
void ReadWriteProblemStartup::handleBackspace()
{
    numberOfReadersInput.handleBackspace();
    numberOfWritersInput.handleBackspace();
    readingDurationInput.handleBackspace();
    writingDurationInput.handleBackspace();
}