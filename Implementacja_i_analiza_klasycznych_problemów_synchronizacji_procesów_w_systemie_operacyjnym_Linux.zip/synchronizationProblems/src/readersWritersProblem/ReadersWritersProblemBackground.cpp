#include "../../include/readersWritersProblem/ReadersWritersProblemBackground.hpp"

#include <iostream>

void ReadersWritersProblemBackground::setup(int nRead, int nWrite, int rDuration, int wDuration, int v)
{
    numberOfReaders = nRead;
    numberOfWriters = nWrite;
    readingDuration = rDuration; 
    writingDuration = wDuration;
    version = (v == 1) ? L"preferencja czytelników" : ((v == 2) ? L"preferencja pisarzy" : L"wersja sprawiedliwa");
    
    bgRec = sf::RectangleShape(sf::Vector2f(Constants::WINDOW_WIDTH, Constants::WINDOW_HEIGHT));
    bgRec.setPosition(0,0);
    bgRec.setFillColor(Constants::BACKGROUND_COLOR);

    if (!font.loadFromFile("../fonts/Arial.ttf"))
    {
        std::cout << "Failed to load font" << std::endl;
    }

    title.setFont(font);
    title.setString(L"Problem czytelników i pisarzy (" + version + L")");
    title.setCharacterSize(20);
    title.setFillColor(sf::Color::Black);
    title.setPosition(10, 10);

    std::wstring infoText = L"";
    infoText += L"Liczba czytelników: " + std::to_wstring(numberOfReaders) + L"\n";
    infoText += L"Liczba pisarzy: : " + std::to_wstring(numberOfWriters) + L"\n";
    infoText += L"Czas trwania czytania: " + std::to_wstring(readingDuration) + L"s\n";
    infoText += L"Czas trwania pisania: " + std::to_wstring(writingDuration) + L"s\n";
    infoText += L"Wciśnij 'r', aby dodać nowego czytelnika lub 'w', aby dodać nowego pisarza.\n";

    info.setFont(font);
    info.setString(infoText);
    info.setCharacterSize(15);
    info.setFillColor(sf::Color::Black);
    info.setPosition(10, 40);

    goBackRec = sf::RectangleShape(sf::Vector2f(80, 40));
    goBackRec.setPosition(705, 15);
    goBackRec.setFillColor(sf::Color(100,100,100));

    goBack.setFont(font);
    goBack.setString(L"Powrót");
    goBack.setCharacterSize(18);
    goBack.setFillColor(sf::Color::Black);
    goBack.setPosition(715, 25);

    line[0].position = sf::Vector2f(5, 140);
    line[1].position = sf::Vector2f(Constants::WINDOW_WIDTH - 5, 140);

    line[0].color = sf::Color::Black;
    line[1].color = sf::Color::Black;

    queueHeader.setFont(font);
    queueHeader.setString(L"Kolejka do czytelni");
    queueHeader.setCharacterSize(20);
    queueHeader.setFillColor(sf::Color::Black);
    queueHeader.setPosition(50, 150);

}

void ReadersWritersProblemBackground::draw(sf::RenderWindow& window)
{
    window.draw(bgRec);
    window.draw(title);
    window.draw(info);
    window.draw(goBackRec);
    window.draw(goBack);
    window.draw(line, 2, sf::Lines);
    window.draw(queueHeader);
}

void ReadersWritersProblemBackground::update(int nRead, int nWrite)
{
    numberOfReaders = nRead;
    numberOfWriters = nWrite;
    std::wstring infoText = L"";
    infoText += L"Liczba czytelników: " + std::to_wstring(numberOfReaders) + L"\n";
    infoText += L"Liczba pisarzy: : " + std::to_wstring(numberOfWriters) + L"\n";
    infoText += L"Czas trwania czytania: " + std::to_wstring(readingDuration) + L"s\n";
    infoText += L"Czas trwania pisania: " + std::to_wstring(writingDuration) + L"s\n";
    infoText += L"Wciśnij 'r', aby dodać nowego czytelnika lub 'w', aby dodać nowego pisarza.\n";
    info.setString(infoText);
}