#include "../../include/readersWritersProblem/Reader.hpp"

#include <iostream>

Reader::Reader(int i, sf::RenderWindow& win, int posX, int posY)
:id(i), window(win), positionX(posX), positionY(posY)
{
    if (!font.loadFromFile("../fonts/Arial.ttf"))
    {
        std::cout << "Failed to load font" << std::endl;
    }

    circle.setFillColor(sf::Color::Red);
    circle.setRadius(6.f);
    circle.setPosition(posX, posY + 4);

    info.setFont(font);
    info.setString(L"Czytelnik id: " + std::to_wstring(id) + L", nieaktywny");
    info.setCharacterSize(15);
    info.setFillColor(sf::Color(20, 20, 20));
    info.setPosition(posX + 20, posY);
}

void Reader::update(Status status, int data)
{
    std::wstring text = L"Czytelnik id: " + std::to_wstring(id) + L", " ;
    if(status == Status::WAITING)
    {
        circle.setFillColor(sf::Color(255, 71, 71));
        text += L"czeka";
    }
    else if(status == Status::READING)
    {
        circle.setFillColor(sf::Color(33, 150, 243));
        text += L"czyta: " + std::to_wstring(data);
    }
    else if(status == Status::DONE)
    {
        circle.setFillColor(sf::Color(76, 175, 80));
        text += L"przeczytał: " + std::to_wstring(data);
    }
    info.setString(text);  
}

void Reader::draw()
{
    window.draw(circle);
    window.draw(info);
}