#include "../include/StartupScreen.hpp"
#include <iostream>

StartupScreen::StartupScreen(sf::RenderWindow& win)
: window(win)
{
    if (!font.loadFromFile("../fonts/Arial.ttf"))
    {
        std::cout << "Failed to load font" << std::endl;
    }

    bgRec = sf::RectangleShape(sf::Vector2f(Constants::WINDOW_WIDTH, Constants::WINDOW_HEIGHT));
    bgRec.setPosition(0,0);
    bgRec.setFillColor(Constants::BACKGROUND_COLOR);

    title.setFont(font);
    title.setString(L"Klasyczne problemy synchronizacji");
    title.setCharacterSize(40);
    title.setFillColor(sf::Color::Black);
    title.setPosition(90, 40);

    int recWidth = 350;
    int recHeigth = 60;

    producersConsumersProblemRec = sf::RectangleShape(sf::Vector2f(recWidth, recHeigth));
    producersConsumersProblemRec.setPosition(225,180);
    producersConsumersProblemRec.setFillColor(sf::Color(100,100,100));

    producersConsumersProblemTitle.setFont(font);
    producersConsumersProblemTitle.setString(L"Problem producenta i konsumenta");
    producersConsumersProblemTitle.setCharacterSize(20);
    producersConsumersProblemTitle.setFillColor(sf::Color::Black);
    producersConsumersProblemTitle.setPosition(245, 200);

    readersWritersProblemRec = sf::RectangleShape(sf::Vector2f(recWidth, recHeigth));
    readersWritersProblemRec.setPosition(225,280);
    readersWritersProblemRec.setFillColor(sf::Color(100,100,100));

    readersWritersProblemTitle.setFont(font);
    readersWritersProblemTitle.setString(L"Problem czytelników i pisarzy");
    readersWritersProblemTitle.setCharacterSize(20);
    readersWritersProblemTitle.setFillColor(sf::Color::Black);
    readersWritersProblemTitle.setPosition(265, 300);

    sleepingBarberProblemRec = sf::RectangleShape(sf::Vector2f(recWidth, recHeigth));
    sleepingBarberProblemRec.setPosition(228,380);
    sleepingBarberProblemRec.setFillColor(sf::Color(100,100,100));

    sleepingBarberProblemTitle.setFont(font);
    sleepingBarberProblemTitle.setString(L"Problem śpiącego golibrody");
    sleepingBarberProblemTitle.setCharacterSize(20);
    sleepingBarberProblemTitle.setFillColor(sf::Color::Black);
    sleepingBarberProblemTitle.setPosition(275, 400);
}

void StartupScreen::draw()
{
    window.draw(bgRec);
    window.draw(title);
    window.draw(producersConsumersProblemRec);
    window.draw(producersConsumersProblemTitle);
    window.draw(readersWritersProblemRec);
    window.draw(readersWritersProblemTitle);
    window.draw(sleepingBarberProblemRec);
    window.draw(sleepingBarberProblemTitle);
}

ProgramStatus StartupScreen::handleEvent(sf::Event event)
{
    if (event.type == sf::Event::MouseButtonPressed)
    {
        if (event.mouseButton.button == sf::Mouse::Left)
        {
            sf::Vector2f mousePosition(static_cast<float>(event.mouseButton.x), static_cast<float>(event.mouseButton.y));
            return handleMouseClick(mousePosition);
        }
    }
    else if (event.type == sf::Event::MouseMoved)
    {
        sf::Vector2f mousePosition(static_cast<float>(event.mouseMove.x), static_cast<float>(event.mouseMove.y));
        handleMouseHover(mousePosition);
    }
    return S_Startup;
}

ProgramStatus StartupScreen::handleMouseClick(sf::Vector2f mousePosition)
{
    if(producersConsumersProblemRec.getGlobalBounds().contains(mousePosition))
    {
        return ProgramStatus::S_ProducersConsumersProblemStartup;
    }
    else if(readersWritersProblemRec.getGlobalBounds().contains(mousePosition))
    {
        return ProgramStatus::S_ReadersWritersProblemStartup;
    }
    else if(sleepingBarberProblemRec.getGlobalBounds().contains(mousePosition))
    {
        return ProgramStatus::S_SleepingBarberProblemStartup;
    }
    return ProgramStatus::S_Startup;
}

void StartupScreen::handleMouseHover(sf::Vector2f mousePosition)
{
    if(producersConsumersProblemRec.getGlobalBounds().contains(mousePosition))
    {
        producersConsumersProblemRec.setFillColor(sf::Color(100,100,200));
    }
    else if(readersWritersProblemRec.getGlobalBounds().contains(mousePosition))
    {
        readersWritersProblemRec.setFillColor(sf::Color(100,100,200));
    }
    else if(sleepingBarberProblemRec.getGlobalBounds().contains(mousePosition))
    {
        sleepingBarberProblemRec.setFillColor(sf::Color(100,100,200));
    }
    else
    {
        producersConsumersProblemRec.setFillColor(sf::Color(100,100,100));
        readersWritersProblemRec.setFillColor(sf::Color(100,100,100));
        sleepingBarberProblemRec.setFillColor(sf::Color(100,100,100));
    }
}