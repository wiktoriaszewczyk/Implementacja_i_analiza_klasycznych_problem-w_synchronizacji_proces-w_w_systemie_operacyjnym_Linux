#include "../../include/sleepingBarberProblem/CustomerQueue.hpp"

void CustomerQueue::addCustomer(Customer* customer)
{
    std::lock_guard<std::mutex> lock(accessToQueue);
    customers.push_back(customer);
    update();
}

void CustomerQueue::removeCustomer()
{
    std::lock_guard<std::mutex> lock(accessToQueue);
    if(!customers.empty())
    {
        customers.pop_front();
    }
    update();
}

void CustomerQueue::update()
{
    int posX = positionX, posY = positionY;
    for(auto& customer : customers)
    {
        customer->update(Customer::WAITING, posX, posY);
        posY += 30;
    }
}
