#include "../../include/sleepingBarberProblem/SleepBarbProblemStartup.hpp"
#include <iostream>

SleepBarbProblemStartup::SleepBarbProblemStartup(sf::RenderWindow& win)
: window(win)
{
    if (!font.loadFromFile("../fonts/Arial.ttf"))
    {
        std::cout << "Failed to load font" << std::endl;
    }

    bgRec = sf::RectangleShape(sf::Vector2f(Constants::WINDOW_WIDTH, Constants::WINDOW_HEIGHT));
    bgRec.setPosition(0,0);
    bgRec.setFillColor(Constants::BACKGROUND_COLOR);

    title.setFont(font);
    title.setString(L"Problem śpiącego golibrody");
    title.setCharacterSize(40);
    title.setFillColor(sf::Color::Black);
    title.setPosition(50, 40);

    prompt.setFont(font);
    prompt.setString(L"Określ warunki początkowe: ");
    prompt.setCharacterSize(18);
    prompt.setFillColor(sf::Color::Black);
    prompt.setPosition(50, 120);

    numberOfCustomersInput.setup(std::wstring(L"Liczba klientów: "), 50, 170, numberOfCustomers);
    numberOfSeatsInput.setup(std::wstring(L"Ilość miejsc w poczekalni: "), 50, 220, numberOfSeats);
    haircutDurationInput.setup(std::wstring(L"Czas trwania strzyżenia: "), 50, 270, haircutDuration);

    std::wstring infoText = L"W problemie występują dwa rodzaje procesów:\n";
                infoText += L"golibroda i klienci. Klienci przychodzą po usługę\n";
                infoText += L"strzyżenia, a golibroda śpi, gdy nie ma klientów. \n";
                infoText += L"Kiedy klient  przychodzi, budzi  golibrodę, który\n";
                infoText += L"następnie  przystępuje do strzyżenia. Jeśli  inni \n";
                infoText += L"klienci  przychodzą   w   międzyczasie,   muszą \n";
                infoText += L"zaczekać na swoją  kolej w poczekalni. Gdy nie\n";
                infoText += L"ma w niej miejsca, odchodzą nieobsłużeni.\n";
                infoText += L"\n";
                infoText += L"W symulacji bierze udział jeden golibroda, który \n";
                infoText += L"może obsługiwać jednego klienta naraz. Można \n";
                infoText += L"ustawić następujące warunki początkowe:\n";
                infoText += L"- liczbę klientów (max 14)\n";
                infoText += L"- liczbę krzeseł w poczekalni <0,10>\n";
                infoText += L"- liczbę krzeseł w poczekalni <0,10>\n";
                infoText += L"  (0 - szczególny przypadek bez poczekalni)\n";
                infoText += L"- czas trwania strzyżenia (w sekundach)\n";

    info.setFont(font);
    info.setString(infoText);
    info.setCharacterSize(16);
    info.setFillColor(sf::Color::Black);
    info.setPosition(420, 120);

    startRec = sf::RectangleShape(sf::Vector2f(200, 40));
    startRec.setPosition(300, 460);
    startRec.setFillColor(sf::Color(100,100,100));

    start.setFont(font);
    start.setString(L"START");
    start.setCharacterSize(20);
    start.setFillColor(sf::Color::Black);
    start.setPosition(370, 468);
}

void SleepBarbProblemStartup::draw()
{
    window.draw(bgRec);
    window.draw(title);
    window.draw(prompt);
    numberOfCustomersInput.draw(window);
    numberOfSeatsInput.draw(window);
    haircutDurationInput.draw(window);
    window.draw(info);
    window.draw(startRec);
    window.draw(start);
}

ProgramStatus SleepBarbProblemStartup::handleEvent(sf::Event event)
{
    if (event.type == sf::Event::MouseButtonPressed)
    {
        if (event.mouseButton.button == sf::Mouse::Left)
        {
            sf::Vector2f mousePosition(static_cast<float>(event.mouseButton.x), static_cast<float>(event.mouseButton.y));
            return handleMouseClick(mousePosition);
        }
    }
    else if (event.type == sf::Event::MouseMoved) {
        sf::Vector2f mousePosition(static_cast<float>(event.mouseMove.x), static_cast<float>(event.mouseMove.y));
        handleMouseHover(mousePosition);
    }
    else if (event.type == sf::Event::TextEntered) {
        handleTextEntered(event.text.unicode);
    }
    else if (event.type == sf::Event::KeyPressed) {
        if (event.key.code == sf::Keyboard::BackSpace) {
            handleBackspace();
        }
    }
    return S_SleepingBarberProblemStartup;
}

ProgramStatus SleepBarbProblemStartup::handleMouseClick(sf::Vector2f mousePosition){
    numberOfCustomersInput.handleMouseClick(mousePosition);
    numberOfSeatsInput.handleMouseClick(mousePosition);
    haircutDurationInput.handleMouseClick(mousePosition);

    if(startRec.getGlobalBounds().contains(mousePosition)){
        numberOfCustomers = std::stoi(numberOfCustomersInput.getValue());
        numberOfSeats = std::stoi(numberOfSeatsInput.getValue());
        haircutDuration = std::stoi(haircutDurationInput.getValue());

        numberOfCustomers = (numberOfCustomers < 0) ? 0 : numberOfCustomers;
        numberOfCustomers = (numberOfCustomers > 14) ? 14 : numberOfCustomers;
        numberOfSeats = (numberOfSeats < 0) ? 0 : numberOfSeats;
        numberOfSeats = (numberOfSeats > 10) ? 10 : numberOfSeats;
        haircutDuration = (haircutDuration < 1) ? 1 : haircutDuration;

        return S_SleepingBarberProblem;
    }
    return S_SleepingBarberProblemStartup;
}

void SleepBarbProblemStartup::handleMouseHover(sf::Vector2f mousePosition)
{
    if(startRec.getGlobalBounds().contains(mousePosition))
        startRec.setFillColor(sf::Color(100,100,200));
    else
        startRec.setFillColor(sf::Color(100,100,100));
}
void SleepBarbProblemStartup::handleTextEntered(sf::Uint32 unicode)
{
    numberOfCustomersInput.handleTextEntered(unicode);
    numberOfSeatsInput.handleTextEntered(unicode);
    haircutDurationInput.handleTextEntered(unicode);
}
void SleepBarbProblemStartup::handleBackspace()
{
    numberOfCustomersInput.handleBackspace();
    numberOfSeatsInput.handleBackspace();
    haircutDurationInput.handleBackspace();
}