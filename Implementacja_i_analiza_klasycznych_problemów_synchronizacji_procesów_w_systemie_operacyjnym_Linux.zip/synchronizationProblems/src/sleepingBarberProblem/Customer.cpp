#include "../../include/sleepingBarberProblem/Customer.hpp"

#include <iostream>

Customer::Customer(int i, sf::RenderWindow& win, int posX, int posY)
:id(i), window(win), positionX(posX), positionY(posY)
{
    if (!font.loadFromFile("../fonts/Arial.ttf"))
    {
        std::cout << "Failed to load font" << std::endl;
    }

    circle.setFillColor(sf::Color::White);
    circle.setRadius(6.f);
    circle.setPosition(posX, posY + 4);

    info.setFont(font);
    info.setString(L"Klient id: " + std::to_wstring(id) + L", nowy");
    info.setCharacterSize(15);
    info.setFillColor(sf::Color::Black);
    info.setPosition(posX + 20, posY);
}

void Customer::update(Status status, int posX, int posY)
{
    std::wstring text = L"Klient id: " + std::to_wstring(id) + L", ";
    if(posX > 0 && posY > 0)
    {
        positionX = posX;
        positionY = posY;
    }

    if(status == Status::WAITING)
    {
        circle.setFillColor(sf::Color(255, 71, 71));
        text += L"czeka";
    }
    else if(status == Status::IN_PROGRESS)
    {
        circle.setFillColor(sf::Color(33, 150, 243));
        // text = L"Klient id: " + std::to_wstring(id);
        text += L"jest obsługiwany";
    }
    else if(status == Status::DONE)
    {
        circle.setFillColor(sf::Color(76, 175, 80));
        text += L"obsłużony";
    }
    else if(status == Status::UNSERVED)
    {
        circle.setFillColor(sf::Color::Black);
        text += L"wyszedł bez strzyżenia";
    }
    info.setString(text); 
    circle.setPosition(positionX, positionY + 4);
    info.setPosition(positionX + 20, positionY);
}

void Customer::draw()
{
    window.draw(circle);
    window.draw(info);
}