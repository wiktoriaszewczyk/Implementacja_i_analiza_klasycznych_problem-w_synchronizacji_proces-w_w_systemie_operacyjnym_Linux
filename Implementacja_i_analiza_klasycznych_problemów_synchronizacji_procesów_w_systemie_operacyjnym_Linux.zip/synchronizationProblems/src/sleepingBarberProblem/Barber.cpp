#include "../../include/sleepingBarberProblem/Barber.hpp"

#include <iostream>

Barber::Barber(sf::RenderWindow& win, int posX, int posY)
:window(win), positionX(posX), positionY(posY)
{
    if (!font.loadFromFile("../fonts/Arial.ttf"))
    {
        std::cout << "Failed to load font" << std::endl;
    }

    circle.setFillColor(sf::Color::Red);
    circle.setRadius(6.f);
    circle.setPosition(posX, posY + 4);

    info.setFont(font);
    info.setString(L"Golibroda: śpi");
    info.setCharacterSize(15);
    info.setFillColor(sf::Color(20, 20, 20));
    info.setPosition(posX + 20, posY);
}

void Barber::update(Status status)
{
    std::wstring text = L"Golibroda: ";
    if(status == Status::SLEEPING)
    {
        circle.setFillColor(sf::Color(255, 71, 71));
        text += L"śpi";
    }
    else if(status == Status::WORKING)
    {
        circle.setFillColor(sf::Color(33, 150, 243));
        text += L"pracuje";
    }
    else if(status == Status::DONE)
    {
        circle.setFillColor(sf::Color(76, 175, 80));
        // text += L"skończył strzyżenie";
        text += L"obsłużył klienta";
    }
    info.setString(text);  
}

void Barber::draw()
{
    window.draw(circle);
    window.draw(info);
}