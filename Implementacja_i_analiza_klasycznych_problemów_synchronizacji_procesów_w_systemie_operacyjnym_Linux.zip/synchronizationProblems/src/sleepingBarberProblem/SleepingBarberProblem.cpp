#include "../../include/sleepingBarberProblem/SleepingBarberProblem.hpp"
#include<iostream>

SleepingBarberProblem::SleepingBarberProblem(sf::RenderWindow& win)
: window(win)
{}

void SleepingBarberProblem::setup(int nCustomers, int nSeats, int hcDuration)
{
    numberOfCustomers = nCustomers;
    numberOfSeats = nSeats;
    haircutDuration = hcDuration;
    
    background.setup(numberOfCustomers, numberOfSeats, haircutDuration);
    
    waitingRoomQueue = new CustomerQueue(80, 280);
    newCustomerList = new CustomerQueue(300, 180);
    xFinishedCustomer = 520;
    yFinishedCustomer = 180;
    barberThreadRunning = true;
    // barberFree = false;
    numberOfFreeSeats = numberOfSeats;
    sem_init(&barberReady, 0, 0);
    sem_init(&waitingForCustomers, 0, 0);

    barber = new Barber(window, 80, 180);
    if(numberOfSeats == 0)
        barberThread = std::thread(&SleepingBarberProblem::barberBehavior_noWaitingRoom, this);
    else
        barberThread = std::thread(&SleepingBarberProblem::barberBehavior, this);

    int positionX = 300, positionY = 180;
    for(int id=1; id<=numberOfCustomers; id++)
    {
        Customer* customer = new Customer(id, window, positionX, positionY);
        customers.push_back(customer);
        if(numberOfSeats == 0)
            customerThreads.push_back(std::thread(&SleepingBarberProblem::customerBehavior_noWaitingRoom, this, customer));
        else
            customerThreads.push_back(std::thread(&SleepingBarberProblem::customerBehavior, this, customer));
    }

}

void SleepingBarberProblem::join()
{
    barberThread.join();

    for(auto& cT : customerThreads)
    {
        cT.join();
    }
}

void SleepingBarberProblem::handleEvent(sf::Event event)
{
    if (event.type == sf::Event::Closed)
    {
        barberThreadRunning = false;
        sem_post(&waitingForCustomers);
    }
    else if (event.type == sf::Event::KeyPressed)
    {
        if (numberOfCustomers < 14)
        {
            if (event.key.code == sf::Keyboard::C)
            {
                int positionX = 300, positionY = 180;
                numberOfCustomers++;
                Customer* customer = new Customer(numberOfCustomers, window, positionX, positionY);
                customers.push_back(customer);
                if(numberOfSeats == 0)
                    customerThreads.push_back(std::thread(&SleepingBarberProblem::customerBehavior_noWaitingRoom, this, customer));
                else
                    customerThreads.push_back(std::thread(&SleepingBarberProblem::customerBehavior, this, customer));
                background.update(numberOfCustomers);
            }
        }
    }
}

void SleepingBarberProblem::del()
{
    sem_destroy(&barberReady);
    sem_destroy(&waitingForCustomers);

    delete waitingRoomQueue;
    delete newCustomerList;
    delete barber;
    for(auto& customer : customers)
    {
        delete customer;
    }
}

void SleepingBarberProblem::draw()
{
    background.draw(window);
    barber->draw();
    for(auto& customer : customers)
    {
        customer->draw();   
    }
}


/////////////////////////////////////////////////////////////////////////////

void SleepingBarberProblem::barberBehavior()
{
    while(barberThreadRunning)  // true
    {
        // SLEEPING
        barber->update(Barber::SLEEPING);
        sem_wait(&waitingForCustomers);
        
        {
            std::lock_guard<std::mutex> lock(mutex);
            numberOfFreeSeats++;
            waitingRoomQueue->removeCustomer();
        }

        sem_post(&barberReady);

        // WORKING
        barber->update(Barber::WORKING);
        std::this_thread::sleep_for(std::chrono::seconds(haircutDuration));
        currentCustomer->update(Customer::DONE, xFinishedCustomer, yFinishedCustomer);
        yFinishedCustomer += 30;
        barber->update(Barber::DONE);
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }
    pthread_exit(NULL);
}

void SleepingBarberProblem::customerBehavior(Customer* customer)
{
    int xCurrentCustomer = 80, yCurrentCustomer = 210;
    newCustomerList->addCustomer(customer);
    std::this_thread::sleep_for(std::chrono::seconds(1));

    std::lock_guard<std::mutex> lock(mutex);
    newCustomerList->removeCustomer();
    if(numberOfFreeSeats > 0)
    {
        numberOfFreeSeats--;
        waitingRoomQueue->addCustomer(customer);
        mutex.unlock();

        customer->update(Customer::WAITING);
        sem_post(&waitingForCustomers);
        sem_wait(&barberReady);
        currentCustomer = customer;
        customer->update(Customer::IN_PROGRESS, xCurrentCustomer, yCurrentCustomer);
    }
    else
    {
        mutex.unlock();
        customer->update(Customer::UNSERVED, xFinishedCustomer, yFinishedCustomer);
        yFinishedCustomer += 30;
    }
    pthread_exit(NULL);
}

void SleepingBarberProblem::barberBehavior_noWaitingRoom()
{
    while(barberThreadRunning)  // true
    {
        // SLEEPING
        barber->update(Barber::SLEEPING);
        {
            std::lock_guard<std::mutex> lock(mutex);
            barberFree = true;
        }
        sem_wait(&waitingForCustomers);
        // sem_post(&barberReady);
        
        // WORKING
        barber->update(Barber::WORKING);
        std::this_thread::sleep_for(std::chrono::seconds(haircutDuration));
        currentCustomer->update(Customer::DONE, xFinishedCustomer, yFinishedCustomer);
        yFinishedCustomer += 30;
        barber->update(Barber::DONE);
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }
    pthread_exit(NULL);
}

void SleepingBarberProblem::customerBehavior_noWaitingRoom(Customer* customer)
{
    int xCurrentCustomer = 80, yCurrentCustomer = 210;
    newCustomerList->addCustomer(customer);
    std::this_thread::sleep_for(std::chrono::seconds(1));

    std::lock_guard<std::mutex> lock(mutex);
    newCustomerList->removeCustomer();
    if(barberFree)
    {
        barberFree = false;
        mutex.unlock();

        sem_post(&waitingForCustomers);
        // sem_wait(&barberReady);
        currentCustomer = customer;
        customer->update(Customer::IN_PROGRESS, xCurrentCustomer, yCurrentCustomer);
    }
    else
    {
        mutex.unlock();
        customer->update(Customer::UNSERVED, xFinishedCustomer, yFinishedCustomer);
        yFinishedCustomer += 30;
    }
    pthread_exit(NULL);
}