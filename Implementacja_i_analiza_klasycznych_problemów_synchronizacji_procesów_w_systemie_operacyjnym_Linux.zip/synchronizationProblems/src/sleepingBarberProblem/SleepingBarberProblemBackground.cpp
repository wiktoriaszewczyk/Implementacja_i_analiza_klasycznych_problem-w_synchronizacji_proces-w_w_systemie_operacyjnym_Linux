#include "../../include/sleepingBarberProblem/SleepingBarberProblemBackground.hpp"

#include <iostream>
#include <random>
#include <chrono>

void SleepingBarberProblemBackground::setup(int nCustomers, int nSeats, int hcDuration)
{
    numberOfCustomers = nCustomers;
    numberOfSeats = nSeats;
    hairCuttingDuration = hcDuration;

    bgRec = sf::RectangleShape(sf::Vector2f(Constants::WINDOW_WIDTH, Constants::WINDOW_HEIGHT));
    bgRec.setPosition(0,0);
    bgRec.setFillColor(Constants::BACKGROUND_COLOR);

    if (!font.loadFromFile("../fonts/Arial.ttf"))
    {
        std::cout << "Failed to load font" << std::endl;
    }

    title.setFont(font);
    title.setString(L"Problem śpiącego golibrody");
    title.setCharacterSize(20);
    title.setFillColor(sf::Color::Black);
    title.setPosition(10, 10);

    std::wstring infoText = L"";
    infoText += L"Liczba klientów: " + std::to_wstring(numberOfCustomers) + L"\n";
    infoText += L"Ilość miejsc w poczekalni: " + std::to_wstring(numberOfSeats) + L"\n";
    infoText += L"Czas trwania strzyżenia: " + std::to_wstring(hairCuttingDuration) + L"s\n";
    infoText += L"\nWciśnij 'c', aby dodać nowego klienta.";

    info.setFont(font);
    info.setString(infoText);
    info.setCharacterSize(15);
    info.setFillColor(sf::Color::Black);
    info.setPosition(10, 40);

    goBackRec = sf::RectangleShape(sf::Vector2f(80, 40));
    goBackRec.setPosition(705, 15);
    goBackRec.setFillColor(sf::Color(100,100,100));

    goBack.setFont(font);
    goBack.setString(L"Powrót");
    goBack.setCharacterSize(18);
    goBack.setFillColor(sf::Color::Black);
    goBack.setPosition(715, 25);

    line[0].position = sf::Vector2f(5, 140);
    line[1].position = sf::Vector2f(Constants::WINDOW_WIDTH - 5, 140);

    line[0].color = sf::Color::Black;
    line[1].color = sf::Color::Black;

    barberShopHeader.setFont(font);
    barberShopHeader.setString("Salon fryzjerski");
    barberShopHeader.setCharacterSize(20);
    barberShopHeader.setFillColor(sf::Color::Black);
    barberShopHeader.setPosition(100, 150);

    waitingRoomHeader.setFont(font);
    waitingRoomHeader.setString("Poczekalnia");
    waitingRoomHeader.setCharacterSize(20);
    waitingRoomHeader.setFillColor(sf::Color::Black);
    waitingRoomHeader.setPosition(100, 250);

    newCustomersHeader.setFont(font);
    newCustomersHeader.setString("Nowi klienci");
    newCustomersHeader.setCharacterSize(20);
    newCustomersHeader.setFillColor(sf::Color::Black);
    newCustomersHeader.setPosition(320, 150);

    inactiveCustomersHeader.setFont(font);
    inactiveCustomersHeader.setString("Nieaktywni klienci");
    inactiveCustomersHeader.setCharacterSize(20);
    inactiveCustomersHeader.setFillColor(sf::Color::Black);
    inactiveCustomersHeader.setPosition(540, 150);

}

void SleepingBarberProblemBackground::draw(sf::RenderWindow& window)
{
    window.draw(bgRec);
    window.draw(title);
    window.draw(info);
    window.draw(goBackRec);
    window.draw(goBack);
    window.draw(line, 2, sf::Lines);
    window.draw(barberShopHeader);
    window.draw(waitingRoomHeader);
    window.draw(newCustomersHeader);
    window.draw(inactiveCustomersHeader);
}

void SleepingBarberProblemBackground::update(int customersN)
{
    numberOfCustomers = customersN;
    std::wstring infoText = L"";
    infoText += L"Liczba klientów: " + std::to_wstring(numberOfCustomers) + L"\n";
    infoText += L"Ilość miejsc w poczekalni: " + std::to_wstring(numberOfSeats) + L"\n";
    infoText += L"Czas trwania strzyżenia: " + std::to_wstring(hairCuttingDuration) + L"s\n";
    infoText += L"\nWciśnij 'c', aby dodać nowego klienta.";
    info.setString(infoText);
}