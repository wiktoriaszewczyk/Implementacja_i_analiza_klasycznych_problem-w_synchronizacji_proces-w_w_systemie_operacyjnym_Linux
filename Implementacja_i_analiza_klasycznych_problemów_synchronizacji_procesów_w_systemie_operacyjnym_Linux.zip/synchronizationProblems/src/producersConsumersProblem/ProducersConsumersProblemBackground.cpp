#include "../../include/producersConsumersProblem/ProducersConsumersProblemBackground.hpp"
#include "../../include/Constants.hpp"

#include <iostream>
// #include <string>

void ProducersConsumersProblemBackground::setup(int nProd, int nCons, int buff, int prodDuration, int consDuration)
{
    numberOfProducers = nProd;
    numberOfConsumers = nCons;
    bufferSize = buff;
    productionDuration = prodDuration;
    consumptionDuration = consDuration;

    bgRec = sf::RectangleShape(sf::Vector2f(Constants::WINDOW_WIDTH, Constants::WINDOW_HEIGHT));
    bgRec.setPosition(0,0);
    bgRec.setFillColor(Constants::BACKGROUND_COLOR);

    if (!font.loadFromFile("../fonts/Arial.ttf"))
    {
        std::cout << "Failed to load font" << std::endl;
    }

    title.setFont(font);
    title.setString(L"Problem producenta i konsumenta");
    title.setCharacterSize(20);
    title.setFillColor(sf::Color::Black);
    title.setPosition(10, 10);

    std::wstring infoText = L"";
    infoText += L"Liczba producentów: " + std::to_wstring(numberOfProducers) + L"\n";
    infoText += L"Liczba konsumentów: " + std::to_wstring(numberOfConsumers) + L"\n";
    infoText += L"Rozmiar bufora: " + std::to_wstring(bufferSize) + L"\n";
    infoText += L"Czas trwania produkcji: " + std::to_wstring(productionDuration) + L"s\n";
    infoText += L"Czas trwania konsumpcji: " + std::to_wstring(consumptionDuration) + L"s\n";;

    info.setFont(font);
    info.setString(infoText);
    info.setCharacterSize(15);
    info.setFillColor(sf::Color::Black);
    info.setPosition(10, 40);

    goBackRec = sf::RectangleShape(sf::Vector2f(80, 40));
    goBackRec.setPosition(705, 15);
    goBackRec.setFillColor(sf::Color(100,100,100));

    goBack.setFont(font);
    goBack.setString(L"Powrót");
    goBack.setCharacterSize(18);
    goBack.setFillColor(sf::Color::Black);
    goBack.setPosition(715, 25);

    line[0].position = sf::Vector2f(5, 140);
    line[1].position = sf::Vector2f(Constants::WINDOW_WIDTH - 5, 140);

    line[0].color = sf::Color::Black;
    line[1].color = sf::Color::Black;

    producersHeader.setFont(font);
    producersHeader.setString("Producenci");
    producersHeader.setCharacterSize(20);
    producersHeader.setFillColor(sf::Color::Black);
    producersHeader.setPosition(100, 150);

    consumersHeader.setFont(font);
    consumersHeader.setString("Konsumenci");
    consumersHeader.setCharacterSize(20);
    consumersHeader.setFillColor(sf::Color::Black);
    consumersHeader.setPosition(500, 150);
    
}

void ProducersConsumersProblemBackground::draw(sf::RenderWindow& window)
{
    window.draw(bgRec);
    window.draw(title);
    window.draw(info);
    window.draw(goBackRec);
    window.draw(goBack);
    window.draw(line, 2, sf::Lines);
    window.draw(producersHeader);
    window.draw(consumersHeader);
}