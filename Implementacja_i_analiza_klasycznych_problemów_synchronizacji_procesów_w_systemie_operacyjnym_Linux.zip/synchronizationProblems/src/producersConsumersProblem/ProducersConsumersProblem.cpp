#include "../../include/producersConsumersProblem/ProducersConsumersProblem.hpp"
#include <random>
#include <deque>
#include <chrono>

ProducersConsumersProblem::ProducersConsumersProblem(sf::RenderWindow& win)
: window(win)
{}

void ProducersConsumersProblem::setup(int nProd, int nCons, int buff, int prodDuration, int consDuration)
{
    numberOfProducers = nProd;
    numberOfConsumers = nCons;
    bufferSize = buff;
    productionDuration = prodDuration;
    consumptionDuration = consDuration;

    background.setup(nProd, nCons, buff, prodDuration, consDuration);

    sem_init(&empty, 0, bufferSize);
    sem_init(&full, 0, 0);

    for(int i=0; i<numberOfProducers; i++)
    {
        Producer* newProducer = new Producer(window, i+1, 80, 180 + i*20);
        producers.push_back(newProducer);
        producerThreads.push_back(std::thread(&ProducersConsumersProblem::producer, this, newProducer));
    }
    for(int i=0; i<numberOfConsumers; i++)
    {
        Consumer* newCustomer = new Consumer(window, i+1, 480, 180 + i*20);
        consumers.push_back(newCustomer);
        consumerThreads.push_back(std::thread(&ProducersConsumersProblem::consumer, this, newCustomer));
    }
}

void ProducersConsumersProblem::join()
{
    for(auto& prod: producerThreads)
    {
        prod.join();
    }
    for(auto& cons: consumerThreads)
    {
        cons.join();
    }
}

void ProducersConsumersProblem::del()
{
    sem_destroy(&empty);
    sem_destroy(&full);

    for(auto& prodV : producers)
    {
        delete prodV;
    }
    for(auto& consV: consumers)
    {
        delete consV;
    }
}

void ProducersConsumersProblem::draw()
{
    background.draw(window);
    bufferWrapper.draw(window);
    for(auto& prodV : producers)
    {
        prodV->draw();
    }
    for(auto& consV : consumers)
    {
        consV->draw();
    }
}


/////////////////////////////////////////////////////////////////////////////

void ProducersConsumersProblem::producer(Producer* prod)
{
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<int> distribution(10, 99);
    int data = distribution(gen);

    prod->update(Producer::WAITING);
    sem_wait(&empty);

    // Producing 
    {
        std::lock_guard<std::mutex> lock(accessToBuffer);
        bufferWrapper.buffer.push_back(data);
        prod->update(Producer::PRODUCING, data);
        std::this_thread::sleep_for(std::chrono::seconds(productionDuration));
        bufferWrapper.update();
    }
    sem_post(&full);

    prod->update(Producer::DONE, data);

    pthread_exit(NULL);
}

void ProducersConsumersProblem::consumer(Consumer* cons)
{
    int data;
    cons->update(Consumer::WAITING);
    sem_wait(&full);

    // Consuming
    {
        std::lock_guard<std::mutex> lock(accessToBuffer);
        data = bufferWrapper.buffer.front();
        bufferWrapper.buffer.pop_front();
        cons->update(Consumer::CONSUMING, data);
        std::this_thread::sleep_for(std::chrono::seconds(consumptionDuration));
        bufferWrapper.update();
    }

    sem_post(&empty);
    cons->update(Consumer::DONE, data);
    pthread_exit(NULL);
}