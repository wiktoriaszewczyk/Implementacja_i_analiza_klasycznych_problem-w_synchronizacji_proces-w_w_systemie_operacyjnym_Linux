#include "../../include/producersConsumersProblem/Consumer.hpp"
#include <iostream>

Consumer::Consumer(sf::RenderWindow& win, int i, int posX, int posY)
: window(win), id(i), positionX(posX), positionY(posY)
{
    if (!font.loadFromFile("../fonts/Arial.ttf"))
    {
        std::cout << "Failed to load font" << std::endl;
    }
    
    circle.setFillColor(sf::Color::Red);
    circle.setRadius(6.f);
    circle.setPosition(posX, posY + 4);

    info.setFont(font);
    info.setString(L"id: " + std::to_wstring(id) + L", nieaktywny");
    info.setCharacterSize(15);
    info.setFillColor(sf::Color::Black);
    info.setPosition(posX + 20, posY);

}

void Consumer::update(Status status, int data){
    std::wstring text = L"id: " + std::to_wstring(id) + L", " ;
    if(status == Status::WAITING)
    {
        circle.setFillColor(sf::Color(255, 71, 71));
        text += L"czeka";
    }
    else if(status == Status::CONSUMING)
    {
        circle.setFillColor(sf::Color(33, 150, 243));
        text += L"konsumuje liczbę: " + std::to_wstring(data);
    }
    else if(status == Status::DONE)
    {
        circle.setFillColor(sf::Color(76, 175, 80));
        text += L"skonsumował liczbę: " + std::to_wstring(data);
    }
    info.setString(text);   
}

void Consumer::draw(){
    window.draw(circle);
    window.draw(info);
}