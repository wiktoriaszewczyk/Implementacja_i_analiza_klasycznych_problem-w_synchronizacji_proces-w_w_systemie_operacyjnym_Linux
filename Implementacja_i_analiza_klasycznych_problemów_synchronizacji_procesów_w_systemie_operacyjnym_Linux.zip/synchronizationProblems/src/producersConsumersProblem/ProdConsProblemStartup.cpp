#include "../../include/producersConsumersProblem/ProdConsProblemStartup.hpp"
#include <iostream>

ProdConsProblemStartup::ProdConsProblemStartup(sf::RenderWindow& win)
: window(win)
{
    if (!font.loadFromFile("../fonts/Arial.ttf"))
    {
        std::cout << "Failed to load font" << std::endl;
    }

    bgRec = sf::RectangleShape(sf::Vector2f(Constants::WINDOW_WIDTH, Constants::WINDOW_HEIGHT));
    bgRec.setPosition(0,0);
    bgRec.setFillColor(Constants::BACKGROUND_COLOR);

    title.setFont(font);
    title.setString(L"Problem producenta i konsumenta");
    title.setCharacterSize(40);
    title.setFillColor(sf::Color::Black);
    title.setPosition(50, 40);

    prompt.setFont(font);
    prompt.setString(L"Określ warunki poczatkowe: ");
    prompt.setCharacterSize(18);
    prompt.setFillColor(sf::Color::Black);
    prompt.setPosition(50, 120);

    numberOfProducersInput.setup(std::wstring(L"Liczba producentów: "), 50, 170, numberOfProducers);
    numberOfConsumersInput.setup(std::wstring(L"Liczba konsumentów: "), 50, 220, numberOfConsumers);
    bufferSizeInput.setup(std::wstring(L"Rozmiar bufora: "), 50, 270, bufferSize);
    productionDurationInput.setup(std::wstring(L"Czas trwania produkcji: "), 50, 320, productionDuration);
    consumptionDurationInput.setup(std::wstring(L"Czas trwania konsumpcji: "), 50, 370, consumptionDuration);
    
    std::wstring infoText = L"W  problemie  występują  dwa  rodzaje  procesów:\n";
                infoText += L"producent i konsument. Dzielą one wspólny bufor,\n";
                infoText += L"do  którego producenci  wkładają wyprodukowane \n";
                infoText += L"produkty (tu liczby). Konsumenci konsumują dane,\n";
                infoText += L"pobierając  je z bufora. Procesy nie  mogą  w tym \n";
                infoText += L"samym  czasie   korzystać  z  bufora, a  kolejność \n";
                infoText += L"konsumpcji  powinna   zgadzać  się  z  kolejnością \n";
                infoText += L"produkcji. Kluczowe jest zapewnienie bezpiecznej\n";
                infoText += L"wymiany  między   producentami  i  konsumentami. \n";
                infoText += L"\n";
                infoText += L"W symulacji można ustawić warunki początkowe: \n";
                infoText += L"- liczbę producentów (max 20),\n";
                infoText += L"- liczbę konsumentów (max 20),\n";
                infoText += L"- wielkość bufora <1,10>,\n";
                infoText += L"- czas trwania produkcji (w sekundach),\n";
                infoText += L"- czas trwania konsumpcji (w sekundach).\n";

    info.setFont(font);
    info.setString(infoText);
    info.setCharacterSize(16);
    info.setFillColor(sf::Color::Black);
    info.setPosition(420, 120);

    startRec = sf::RectangleShape(sf::Vector2f(200, 40));
    startRec.setPosition(300, 450);
    startRec.setFillColor(sf::Color(100,100,100));

    start.setFont(font);
    start.setString(L"START");
    start.setCharacterSize(20);
    start.setFillColor(sf::Color::Black);
    start.setPosition(370, 458);
}

void ProdConsProblemStartup::draw()
{
    window.draw(bgRec);
    window.draw(title);
    window.draw(prompt);
    numberOfProducersInput.draw(window);
    numberOfConsumersInput.draw(window);
    bufferSizeInput.draw(window);
    productionDurationInput.draw(window);
    consumptionDurationInput.draw(window);
    window.draw(info);
    window.draw(startRec);
    window.draw(start);
}

ProgramStatus ProdConsProblemStartup::handleEvent(sf::Event event)
{
    if (event.type == sf::Event::MouseButtonPressed)
    {
        if (event.mouseButton.button == sf::Mouse::Left)
        {
            sf::Vector2f mousePosition(static_cast<float>(event.mouseButton.x), static_cast<float>(event.mouseButton.y));
            return handleMouseClick(mousePosition);
        }
    }
    else if (event.type == sf::Event::MouseMoved) {
        sf::Vector2f mousePosition(static_cast<float>(event.mouseMove.x), static_cast<float>(event.mouseMove.y));
        handleMouseHover(mousePosition);
    }
    else if (event.type == sf::Event::TextEntered) {
        handleTextEntered(event.text.unicode);
    }
    else if (event.type == sf::Event::KeyPressed) {
        if (event.key.code == sf::Keyboard::BackSpace) {
            handleBackspace();
        }
    }
    return S_ProducersConsumersProblemStartup;
}

ProgramStatus ProdConsProblemStartup::handleMouseClick(sf::Vector2f mousePosition){
    numberOfProducersInput.handleMouseClick(mousePosition);
    numberOfConsumersInput.handleMouseClick(mousePosition);
    bufferSizeInput.handleMouseClick(mousePosition);
    productionDurationInput.handleMouseClick(mousePosition);
    consumptionDurationInput.handleMouseClick(mousePosition);

    if(startRec.getGlobalBounds().contains(mousePosition)){
        numberOfProducers = std::stoi(numberOfProducersInput.getValue());
        numberOfConsumers = std::stoi(numberOfConsumersInput.getValue());
        bufferSize = std::stoi(bufferSizeInput.getValue());
        productionDuration = std::stoi(productionDurationInput.getValue());
        consumptionDuration = std::stoi(consumptionDurationInput.getValue());

        numberOfProducers = (numberOfProducers < 0) ? 10 : numberOfProducers;
        numberOfConsumers = (numberOfConsumers < 0) ? 10 : numberOfConsumers;
        
        numberOfProducers = (numberOfProducers > numberOfConsumers + bufferSize) ? numberOfConsumers + bufferSize : numberOfProducers;
        numberOfProducers = (numberOfProducers > 20) ? 20 : numberOfProducers;
        
        bufferSize = (bufferSize < 1) ? 1 : bufferSize; 
        bufferSize = (bufferSize > 10) ? 10 : bufferSize; 

        numberOfConsumers = (numberOfConsumers > numberOfProducers) ? numberOfProducers : numberOfConsumers;
        numberOfConsumers = (numberOfConsumers > 20) ? 20 : numberOfConsumers;
        
        productionDuration = (productionDuration < 0) ? 1 : productionDuration;
        consumptionDuration = (consumptionDuration < 0) ? 1 : consumptionDuration;

        return S_ProducersConsumersProblem;
    }
    return S_ProducersConsumersProblemStartup;
}

void ProdConsProblemStartup::handleMouseHover(sf::Vector2f mousePosition)
{
    if(startRec.getGlobalBounds().contains(mousePosition))
        startRec.setFillColor(sf::Color(100,100,200));
    else
        startRec.setFillColor(sf::Color(100,100,100));
}
void ProdConsProblemStartup::handleTextEntered(sf::Uint32 unicode)
{
    numberOfProducersInput.handleTextEntered(unicode);
    numberOfConsumersInput.handleTextEntered(unicode);
    bufferSizeInput.handleTextEntered(unicode);
    productionDurationInput.handleTextEntered(unicode);
    consumptionDurationInput.handleTextEntered(unicode);
}
void ProdConsProblemStartup::handleBackspace()
{
    numberOfProducersInput.handleBackspace();
    numberOfConsumersInput.handleBackspace();
    bufferSizeInput.handleBackspace();
    productionDurationInput.handleBackspace();
    consumptionDurationInput.handleBackspace();
}