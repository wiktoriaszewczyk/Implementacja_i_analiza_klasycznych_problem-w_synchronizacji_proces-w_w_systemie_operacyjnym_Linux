#include "../../include/producersConsumersProblem/BufferWrapper.hpp"
#include <iostream>

BufferWrapper::BufferWrapper()
{
    if (!font.loadFromFile("../fonts/Arial.ttf"))
    {
        std::cout << "Failed to load font" << std::endl;
    }

    bufferVisualization.setFont(font);
    bufferVisualization.setString(L"Bufor: ");
    bufferVisualization.setCharacterSize(20);
    bufferVisualization.setFillColor(sf::Color::Black);
    bufferVisualization.setPosition(350, 90);
}

void BufferWrapper::update()
{
    std::wstring elementsFromBuffer = L"";
    for (const auto& element : buffer) {
        elementsFromBuffer += std::to_wstring(element) + L"  ";
    }
    bufferVisualization.setString(L"Bufor:  " + elementsFromBuffer);
}

void  BufferWrapper::draw(sf::RenderWindow& window)
{
    window.draw(bufferVisualization);
}