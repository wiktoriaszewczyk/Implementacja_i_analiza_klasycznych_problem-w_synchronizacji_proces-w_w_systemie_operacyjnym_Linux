#pragma once
#include <SFML/Graphics.hpp>
#include <vector>
#include <thread>
#include <semaphore.h>
#include <mutex>
#include <functional>

#include "ReadersWritersProblemBackground.hpp"
#include "Reader.hpp"
#include "Writer.hpp"

class ReadersWritersProblem
{
public:
    ReadersWritersProblem(sf::RenderWindow& win);
    void del();
    void setup(int nRead, int nWrite, int rDuration, int wDuration, int v);
    void draw();
    void join();
    void handleEvent(sf::Event event);

private:
    sf::RenderWindow& window;
    int numberOfReaders = 10;
    int numberOfWriters = 5;
    int readingDuration = 1; // [s]
    int writingDuration = 1; // [s]
    int version = 3;
    std::function<void(Reader*)> reading;
    std::function<void(Writer*)> writing;

    ReadersWritersProblemBackground background;
    int positionX;
    int positionY;

    std::vector<Reader*> readers;
    std::vector<std::thread> readerThreads;
    std::vector<Writer*> writers;
    std::vector<std::thread> writerThreads;
    int resource = 10;
    int readersCount = 0;
    int writersCount = 0;
    std::mutex accessToReadersCount;
    std::mutex accessToWritersCount;
    sem_t queue;
    sem_t accessToResource; 
    sem_t writerPreference;

    bool randomBool();
    void updateXYposition();

    void reading_readersPreference(Reader* reader);
    void writing_readersPreference(Writer* writer);

    void reading_writersPreference(Reader* reader);
    void writing_writersPreference(Writer* writer);

    void reading_withoutStarvation(Reader* reader);
    void writing_withoutStarvation(Writer* writer);
};