#pragma once
#include <SFML/Graphics.hpp>
#include "../Constants.hpp"
class ReadersWritersProblemBackground
{
public:
    ReadersWritersProblemBackground(){}
    void setup(int nRead, int nWrite, int rDuration, int wDuration, int v);
    void draw(sf::RenderWindow& window);
    void update(int nRead, int nWrite);
private:
    int numberOfReaders;
    int numberOfWriters;
    int readingDuration;
    int writingDuration;
    std::wstring version;    // 1 = readers-preference, 2 = writers-preference, 3 = without starvation
    
    sf::RectangleShape bgRec;
    sf::Font font;
    sf::Text title;
    sf::Text info;
    sf::RectangleShape goBackRec;
    sf::Text goBack;

    sf::Vertex line[2];

    sf::Text queueHeader;
};