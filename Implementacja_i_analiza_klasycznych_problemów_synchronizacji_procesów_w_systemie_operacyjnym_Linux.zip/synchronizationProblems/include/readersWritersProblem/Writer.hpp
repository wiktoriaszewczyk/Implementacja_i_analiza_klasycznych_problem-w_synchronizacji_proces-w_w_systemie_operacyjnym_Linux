#pragma once
#include <SFML/Graphics.hpp>
class Writer
{
public: 
    Writer(int i, sf::RenderWindow& win, int posX, int posY);
    enum Status{
        WAITING,
        WRITING,
        DONE
    };
    void update(Status status, int data = -1);
    void draw();
private:

    int id;
    sf::RenderWindow& window;
    int positionX;
    int positionY;
    sf::CircleShape circle;
    sf::Font font;
    sf::Text info;

};