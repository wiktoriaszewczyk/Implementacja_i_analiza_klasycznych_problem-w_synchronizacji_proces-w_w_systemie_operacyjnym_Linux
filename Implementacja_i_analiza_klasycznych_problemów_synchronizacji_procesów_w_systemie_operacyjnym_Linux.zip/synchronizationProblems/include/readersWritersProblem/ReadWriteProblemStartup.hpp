#pragma once
#include <SFML/Graphics.hpp>
#include "../Constants.hpp"
#include "../InputBox.hpp"

class ReadWriteProblemStartup
{
public:
    ReadWriteProblemStartup(sf::RenderWindow& win);
    void draw();
    ProgramStatus handleEvent(sf::Event event);

    int numberOfReaders = 10;
    int numberOfWriters = 5;
    int readingDuration = 1; // [s]
    int writingDuration = 1; // [s]
    int version = 3;
private:
    ProgramStatus handleMouseClick(sf::Vector2f mousePosition);
    void handleMouseHover(sf::Vector2f mousePosition);
    void handleTextEntered(sf::Uint32 unicode);
    void handleBackspace();

    sf::RenderWindow& window;
    sf::RectangleShape bgRec;
    sf::Font font;
    sf::Text title;
    sf::Text prompt;

    InputBox numberOfReadersInput;
    InputBox numberOfWritersInput;
    InputBox readingDurationInput;
    InputBox writingDurationInput;

    sf::RectangleShape version1Rec;
    sf::Text version1;
    sf::RectangleShape version2Rec;
    sf::Text version2;
    sf::RectangleShape version3Rec;
    sf::Text version3;

    sf::Text info;

    sf::RectangleShape startRec;
    sf::Text start;
};