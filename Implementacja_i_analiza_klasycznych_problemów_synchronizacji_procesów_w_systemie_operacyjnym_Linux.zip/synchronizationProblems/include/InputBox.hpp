#pragma once
#include <SFML/Graphics.hpp>

class InputBox
{
public:
    InputBox(){};
    void setup(std::wstring text, int positionX, int positionY, int value);
    void draw(sf::RenderWindow& window);
    void handleMouseClick(sf::Vector2f mousePosition);
    void handleTextEntered(sf::Uint32 unicode);
    void handleBackspace();
    std::string getValue() const;
private:
    sf::Font font;
    sf::Text title;
    sf::RectangleShape rectangle;
    sf::Text input;
    std::string inputText;

    bool selected = false;
};