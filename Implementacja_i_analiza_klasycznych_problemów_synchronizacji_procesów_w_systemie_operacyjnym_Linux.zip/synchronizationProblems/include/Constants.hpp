#pragma once
#include <SFML/Graphics.hpp>

namespace Constants {
    constexpr int WINDOW_WIDTH = 800;
    constexpr int WINDOW_HEIGHT = 600;
    const sf::Color BACKGROUND_COLOR(200,200,200);
}

enum ProgramStatus{
    S_Startup,
    S_ProducersConsumersProblemStartup,
    S_ProducersConsumersProblem,
    S_ReadersWritersProblemStartup,
    S_ReadersWritersProblem,
    S_SleepingBarberProblemStartup,
    S_SleepingBarberProblem
};