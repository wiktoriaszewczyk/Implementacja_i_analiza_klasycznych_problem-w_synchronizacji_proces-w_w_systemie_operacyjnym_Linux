#pragma once
#include <SFML/Graphics.hpp>
#include "../include/Constants.hpp"

class StartupScreen
{
public:    
    StartupScreen(sf::RenderWindow& win);
    void draw();
    ProgramStatus handleEvent(sf::Event event);
private:
    ProgramStatus handleMouseClick(sf::Vector2f mousePosition);
    void handleMouseHover(sf::Vector2f mousePosition);
    sf::RenderWindow& window;
    sf::RectangleShape bgRec;
    sf::Font font;
    sf::Text title;
    sf::Text producersConsumersProblemTitle;
    sf::Text readersWritersProblemTitle;
    sf::Text sleepingBarberProblemTitle;

    sf::RectangleShape producersConsumersProblemRec;
    sf::RectangleShape readersWritersProblemRec;
    sf::RectangleShape sleepingBarberProblemRec;
};