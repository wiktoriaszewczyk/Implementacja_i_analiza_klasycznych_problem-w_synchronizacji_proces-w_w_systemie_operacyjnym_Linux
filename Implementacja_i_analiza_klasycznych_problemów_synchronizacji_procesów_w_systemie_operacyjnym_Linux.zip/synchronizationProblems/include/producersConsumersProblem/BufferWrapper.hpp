#pragma once
#include <SFML/Graphics.hpp>
#include <deque>

class BufferWrapper
{
public:
    BufferWrapper();
    void update();
    void draw(sf::RenderWindow& window);

    std::deque<int> buffer;
private:
    sf::Font font;
    sf::Text bufferVisualization;
};