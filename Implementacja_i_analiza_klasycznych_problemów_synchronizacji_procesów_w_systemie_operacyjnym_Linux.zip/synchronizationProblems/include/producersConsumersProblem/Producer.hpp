#pragma once
#include <SFML/Graphics.hpp>

class Producer
{
public:
    Producer(sf::RenderWindow& win, int i, int posX, int posY);
    enum Status{
        WAITING,
        PRODUCING,
        DONE
    };
    void update(Status status, int data = -1);
    void draw();
private:
    sf::RenderWindow& window;
    int id;
    int positionX;
    int positionY;
    sf::CircleShape circle;
    sf::Font font;
    sf::Text info;
};