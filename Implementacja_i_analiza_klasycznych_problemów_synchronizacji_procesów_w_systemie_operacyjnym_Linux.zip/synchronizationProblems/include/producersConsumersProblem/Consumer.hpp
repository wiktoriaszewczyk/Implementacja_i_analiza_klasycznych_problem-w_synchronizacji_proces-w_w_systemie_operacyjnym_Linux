#pragma once
#include <SFML/Graphics.hpp>

class Consumer
{
public:
    Consumer(sf::RenderWindow& win, int i, int posX, int posY);
    enum Status{
        WAITING,
        CONSUMING,
        DONE
    };
    void update(Status status, int data = -1);
    void draw();
private:
    sf::RenderWindow& window;
    int id;
    int positionX;
    int positionY;
    sf::CircleShape circle;
    sf::Font font;
    sf::Text info;
};