#pragma once
#include <SFML/Graphics.hpp>
#include "../Constants.hpp"
#include "../InputBox.hpp"

class ProdConsProblemStartup
{
public:    
    ProdConsProblemStartup(sf::RenderWindow& win);
    void draw();
    ProgramStatus handleEvent(sf::Event event);

    int numberOfProducers = 10;
    int numberOfConsumers = 10;
    int bufferSize = 5;
    int productionDuration = 1;  // [s]
    int consumptionDuration = 1;  // [s]

private:
    ProgramStatus handleMouseClick(sf::Vector2f mousePosition);
    void handleMouseHover(sf::Vector2f mousePosition);
    void handleTextEntered(sf::Uint32 unicode);
    void handleBackspace();

    sf::RenderWindow& window;
    sf::RectangleShape bgRec;
    sf::Font font;
    sf::Text title;
    sf::Text prompt;

    InputBox numberOfProducersInput;
    InputBox numberOfConsumersInput;
    InputBox bufferSizeInput;
    InputBox productionDurationInput;
    InputBox consumptionDurationInput;

    sf::Text info;

    sf::RectangleShape startRec;
    sf::Text start;
};
