#pragma once
#include <SFML/Graphics.hpp>
#include <thread>
#include <semaphore.h>
#include <mutex>

#include "ProducersConsumersProblemBackground.hpp"
#include "BufferWrapper.hpp"
#include "Producer.hpp"
#include "Consumer.hpp"

class ProducersConsumersProblem
{
public:
    ProducersConsumersProblem(sf::RenderWindow& win);
    void setup(int nProd, int nCons, int buff, int prodDuration, int consDuration);
    void del();
    void join();
    void draw();

private:
    sf::RenderWindow& window;
    int numberOfProducers;
    int numberOfConsumers;
    int bufferSize;
    int productionDuration;
    int consumptionDuration;

    ProducersConsumersProblemBackground background;
    BufferWrapper bufferWrapper;
    std::mutex accessToBuffer;
    sem_t empty;
    sem_t full;
    std::vector<std::thread> producerThreads;
    std::vector<std::thread> consumerThreads;
    std::vector<Consumer*> consumers;
    std::vector<Producer*> producers;

    void producer(Producer* prod);
    void consumer(Consumer* cons);
};