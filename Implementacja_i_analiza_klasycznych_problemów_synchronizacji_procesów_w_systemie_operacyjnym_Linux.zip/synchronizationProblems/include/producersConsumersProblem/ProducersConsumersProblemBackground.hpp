#pragma once
#include <SFML/Graphics.hpp>

class ProducersConsumersProblemBackground
{
public:
    ProducersConsumersProblemBackground(){};
    void setup(int nProd, int nCons, int buffS, int prodDuration, int consDuration);
    void draw(sf::RenderWindow& win);
private:

    int numberOfProducers = 10;
    int numberOfConsumers = 10;
    int bufferSize = 5;
    int productionDuration = 1;
    int consumptionDuration = 1;
    
    sf::RectangleShape bgRec;
    sf::Font font;
    sf::Text title;
    sf::Text info;
    sf::RectangleShape goBackRec;
    sf::Text goBack;

    sf::Vertex line[2];

    sf::Text producersHeader;
    sf::Text consumersHeader;
};