#pragma once
#include <SFML/Graphics.hpp>
#include "../Constants.hpp"

class SleepingBarberProblemBackground
{
public:
    SleepingBarberProblemBackground(){};
    void setup(int nCustomers, int nSeats, int hcDuration);
    void draw(sf::RenderWindow& window);
    void update(int customersN);
private:
    int numberOfCustomers;
    int numberOfSeats;
    int hairCuttingDuration;
    
    sf::RectangleShape bgRec;
    sf::Font font;
    sf::Text title;
    sf::Text info;
    sf::RectangleShape goBackRec;
    sf::Text goBack;

    sf::Vertex line[2];

    sf::Text barberShopHeader;
    sf::Text waitingRoomHeader;
    sf::Text newCustomersHeader;
    sf::Text inactiveCustomersHeader;
};