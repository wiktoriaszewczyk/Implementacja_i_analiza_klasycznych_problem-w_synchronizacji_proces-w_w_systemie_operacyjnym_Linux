#pragma once
#include <SFML/Graphics.hpp>

class Customer
{
public: 
    Customer(int i, sf::RenderWindow& win, int posX, int posY);
    enum Status{
        WAITING,
        IN_PROGRESS,
        DONE,
        UNSERVED
    };
    void update(Status status, int posX = -1, int posY = -1);
    void draw();
private:

    int id;
    sf::RenderWindow& window;
    int positionX;
    int positionY;
    sf::CircleShape circle;
    sf::Font font;
    sf::Text info;

};