#pragma once
#include <SFML/Graphics.hpp>
#include <deque>
#include <mutex>

#include "Customer.hpp"

class CustomerQueue
{
public:
    CustomerQueue(int posX, int posY): positionX(posX), positionY(posY){}
    void addCustomer(Customer* customer);
    void removeCustomer();
private:
    void update();
    std::deque<Customer*> customers;
    std::mutex accessToQueue;
    int positionX;
    int positionY;
};