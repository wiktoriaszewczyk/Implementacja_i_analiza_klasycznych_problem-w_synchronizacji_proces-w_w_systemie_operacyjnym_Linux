#pragma once
#include <SFML/Graphics.hpp>

class Barber
{
public: 
    Barber(sf::RenderWindow& win, int posX, int posY);
    enum Status{
        SLEEPING,
        WORKING,
        DONE
    };
    void update(Status status);
    void draw();
private:
    sf::RenderWindow& window;
    int positionX;
    int positionY;
    sf::CircleShape circle;
    sf::Font font;
    sf::Text info;

};