#pragma once
#include <SFML/Graphics.hpp>
#include "../Constants.hpp"
#include "../InputBox.hpp"

class SleepBarbProblemStartup
{
public:    
    SleepBarbProblemStartup(sf::RenderWindow& win);
    void draw();
    ProgramStatus handleEvent(sf::Event event);

    int numberOfCustomers = 5;
    int numberOfSeats = 3;
    int haircutDuration = 1; // [s]

private:
    ProgramStatus handleMouseClick(sf::Vector2f mousePosition);
    void handleMouseHover(sf::Vector2f mousePosition);
    void handleTextEntered(sf::Uint32 unicode);
    void handleBackspace();

    sf::RenderWindow& window;
    sf::RectangleShape bgRec;
    sf::Font font;
    sf::Text title;
    sf::Text prompt;

    InputBox numberOfCustomersInput;
    InputBox numberOfSeatsInput;
    InputBox haircutDurationInput;

    sf::Text info;

    sf::RectangleShape startRec;
    sf::Text start;
};
