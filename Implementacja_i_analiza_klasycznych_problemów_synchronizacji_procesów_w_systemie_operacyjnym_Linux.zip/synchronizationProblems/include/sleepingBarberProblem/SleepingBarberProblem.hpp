#pragma once
#include <SFML/Graphics.hpp>
#include <vector>
#include <deque>
#include <thread>
#include <semaphore.h>
#include <mutex>

#include "SleepingBarberProblemBackground.hpp"
#include "CustomerQueue.hpp"
#include "Barber.hpp"
#include "Customer.hpp"

class SleepingBarberProblem
{
public:
    SleepingBarberProblem(sf::RenderWindow& win);
    void setup(int nCustomers, int nSeats, int hcDuration);
    void del();
    void join();
    void handleEvent(sf::Event event);
    void draw();

private:
    sf::RenderWindow& window;
    int numberOfCustomers;
    int numberOfSeats;
    int haircutDuration;

    SleepingBarberProblemBackground background;
    CustomerQueue* waitingRoomQueue;
    CustomerQueue* newCustomerList;
    Customer* currentCustomer;
    Barber* barber;
    std::vector<Customer*> customers;
    int xFinishedCustomer = 520;
    int yFinishedCustomer = 180;

    bool barberThreadRunning = true;
    int numberOfFreeSeats;
    bool barberFree;
    sem_t barberReady;
    sem_t waitingForCustomers;
    std::mutex mutex;
    std::thread barberThread;
    std::vector<std::thread> customerThreads;

    void barberBehavior();
    void customerBehavior(Customer* customer);
    void barberBehavior_noWaitingRoom();
    void customerBehavior_noWaitingRoom(Customer* customer);

};